# Spring Boot REST API Boilerplate

## Overview
This is a REST API boilerplate built with Spring Boot for rapid development. It supports MySQL as the database and follows the layered architecture pattern with controllers, services, and repositories.

## Features
- CRUD operations for users
- Spring Data JPA for MySQL integration
- Clean architecture with separate layers
- Easy to extend and customize

## Installation

### Prerequisites
- JDK 17 or later
- MySQL Database setup
- Maven

### Setup

1. Clone the repository:
    ```bash
    git clone https://github.com/yourusername/spring-boot-rest-api-boilerplate.git
    ```

2. Navigate to the project folder:
    ```bash
    cd spring-boot-rest-api-boilerplate
    ```

3. Update the database credentials in `src/main/resources/application.properties` file:
    ```properties
    spring.datasource.url=jdbc:mysql://localhost:3306/your_database
    spring.datasource.username=sonu
    spring.datasource.password=System123#
    ```

4. Run the application:
    ```bash
    mvn spring-boot:run
    ```

5. Access the API on `http://localhost:8080`

## API Endpoints

### GET /users
Fetch all users.

### POST /users
Create a new user.

### GET /users/{id}
Fetch user by ID.

### PUT /users/{id}
Update user by ID.

### DELETE /users/{id}
Delete user by ID.

## License
This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details.

## Contact
For any questions or support, please reach out at [psruhaan9101@gmail.com](mailto:psruhaan9101@gmail.com).
