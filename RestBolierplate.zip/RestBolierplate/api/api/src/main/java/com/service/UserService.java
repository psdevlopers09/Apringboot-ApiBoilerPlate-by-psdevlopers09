package com.service;
import com.model.User;
public interface UserService {
	 User registerUser(User user);

}
