package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiBoilerplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApiBoilerplateApplication.class, args);
	}

}
